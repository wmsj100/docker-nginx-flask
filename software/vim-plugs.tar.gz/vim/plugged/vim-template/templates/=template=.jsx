/*
 * %FFILE%
 * Copyright (C) %YEAR% %USER% <%MAIL%>
 *
 * Distributed under terms of the %LICENSE% license.
 */
import React, { Component } from 'react'


class %FILE% extends Component {
  constructor(props: any) {
    super(props)

  }

  render() {
    return (
      %HERE%
    )
  }
}
